# "I Can't Believe It's Not Better!" (ICBINB) Workshop

["I Can't Believe It's Not Better!" (ICBINB)](https://i-cant-believe-its-not-better.github.io/) will be held **virtually on Saturday December 12, 2020** as a workhop at [NeurIPS 2020](https://nips.cc/Conferences/2020).

## Submission Information

Please see our [CFP](https://i-cant-believe-its-not-better.github.io/cfp/).

Submissions will be accepted through [OpenReview](https://openreview.net/group?id=NeurIPS.cc/2020/Workshop/ICBINB).

Main deadline: **~~October 14~~ October 16 23:59 Anywhere on Earth**. Accept/reject notification will be sent out by October 31st.

