---
layout: page
permalink: /feedback/
title: Feedback
description:
---

We would love to hear your feedback, simply answer the [following short survey](https://forms.gle/PvKLEDqa2jLnwqJ19).


For any other question or suggestion, please contact us at: <cant.believe.it.is.not.better@gmail.com>
